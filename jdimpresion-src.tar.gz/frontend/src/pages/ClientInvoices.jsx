import React from 'react'

export default function ClientInvoices() {
  return (
    <div className="max-w-5xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Mis Facturas</h1>
      <div className="bg-white rounded shadow p-4">Listado de facturas (placeholder)</div>
    </div>
  )
}
