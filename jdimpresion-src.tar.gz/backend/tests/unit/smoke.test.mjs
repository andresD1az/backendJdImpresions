describe('smoke', () => {
  test('jest is running', () => {
    expect(1 + 1).toBe(2)
  })
})
